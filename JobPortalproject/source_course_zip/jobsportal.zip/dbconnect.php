<?php

$con = mysqli_connect('localhost','root','','dbjobsportal');

if(!$con){
    die('cannot connected');
}

?>