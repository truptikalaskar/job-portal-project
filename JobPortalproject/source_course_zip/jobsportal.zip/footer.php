<div class="footer_bottom">	
  <div class="container">
   
  	<div class="clearfix"> </div>
	<div class="copy">
		<p>Copyright © 2020 . All Rights Reserved . Design by <a href="http://www.approxsol.com/" target="_blank">ApproxSol.</a> </p>
	</div>
  </div>
</div>